
License
-------

    Unless stated otherwise, all code and material is licensed under a

    Creative Commons Attribution 4.0 International License (CC-BY)

    http://creativecommons.org/licenses/by/4.0/

    See the AUTHORS.rst file for a list of contributors.


Authors
-------

Kristian Rother
Paul Wlodkowski
Malte Bonart
Stefan Roth
Ugur Ural
Tom Gadsby
Gesa Johannsen
Samuel Adams McGuire
Sara Maras


Theme
-----

The Sphinx theme is derived from scipy-lectures.org and distributed under the same license.
See a list of respetive authors there.